import {v4 as uuidv4} from 'uuid';
import img1 from '../../assets/img/client/1.jpg';

const TestimonialTwoData = [
    {
        id: uuidv4(),
        img: img1,
        name: 'CEO, Snyder Digital',
        designation: 'Contructor',
        speech: 'Construction is an ancient human activity. It began with the purely functional need for a controlled environment to moderate the effects of climate. Constructed shelters were one means by which human beings wereable to adapt themselves to a wide variety of climates .',
    },

    {
        id: uuidv4(),
        img: img1,
        name: 'Salman Ahned',
        designation: 'CEO, Modina Themes',
        speech: 'Construction is an ancient human activity. It began with the purely functional need for a controlled environment to moderate the effects of climate. Constructed shelters were one means by which human beings wereable to adapt themselves to a wide variety of climates .',
    },
    
]

export default TestimonialTwoData;